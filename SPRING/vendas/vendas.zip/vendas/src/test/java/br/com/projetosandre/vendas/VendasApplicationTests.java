package br.com.projetosandre.vendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
